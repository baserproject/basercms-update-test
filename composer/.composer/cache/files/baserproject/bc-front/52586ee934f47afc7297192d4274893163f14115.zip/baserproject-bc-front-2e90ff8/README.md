# BcFront plugin for baserCMS

## About
This is the default theme for the front page of baserCMS.
This theme implements all the basic functions, and the design is as simple as possible to make it easy to change the design based on this theme.

## Installation

You can install this plugin into your baserCMS application using [composer](https://getcomposer.org).

The recommended way to install composer packages is:

```
composer require baserproject/BcFront
```

## Contributing
- [BcFront の開発](https://baserproject.github.io/5/core_theme/front_theme)


