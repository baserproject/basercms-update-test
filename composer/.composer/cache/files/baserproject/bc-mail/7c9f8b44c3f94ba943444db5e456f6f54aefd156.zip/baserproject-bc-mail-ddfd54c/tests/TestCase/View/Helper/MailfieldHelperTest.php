<?php
// TODO ucmitz  : コード確認要
return;
/**
 * baserCMS :  Based Website Development Project <https://basercms.net>
 * Copyright (c) baserCMS Users Community <https://basercms.net/community/>
 *
 * @copyright       Copyright (c) baserCMS Users Community
 * @link            https://basercms.net baserCMS Project
 * @since           baserCMS v 4.0.9
 * @license         https://basercms.net/license/index.html
 */

App::uses('MailfieldHelper', 'BcMail.View/Helper');

class MailfieldHelperTest extends BaserTestCase
{

    /**
     * set up
     */
    public function setUp()
    {
        parent::setUp();
    }

    /**
     * tear down
     */
    public function tearDown()
    {
        parent::tearDown();
    }

    /**
     * htmlの属性を取得する
     */
    public function testGetAttributes()
    {
        $this->markTestIncomplete('このテストは、まだ実装されていません。');
    }

    /**
     * コントロールのソースを取得する
     */
    public function testGetOptions()
    {
        $this->markTestIncomplete('このテストは、まだ実装されていません。');
    }
}
