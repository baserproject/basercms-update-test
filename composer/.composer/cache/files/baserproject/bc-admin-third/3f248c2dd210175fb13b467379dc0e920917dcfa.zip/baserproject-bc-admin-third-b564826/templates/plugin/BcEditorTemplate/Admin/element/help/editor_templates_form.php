<?php
/**
 * baserCMS :  Based Website Development Project <https://basercms.net>
 * Copyright (c) baserCMS Users Community <https://basercms.net/community/>
 *
 * @copyright       Copyright (c) baserCMS Users Community
 * @link            https://basercms.net baserCMS Project
 * @since           baserCMS v 2.0.0
 * @license         https://basercms.net/license/index.html
 */

/**
 * [ADMIN] エディタテンプレート編集画面　ヘルプ
 */
?>


<p><?php echo __d('baser_core', '固定ページ等で利用するエディタのテンプレートを登録します。<br />テンプレートには、画像も貼り付ける事ができます。<br />また、アイコン画像は、横幅100pxが推奨です。') ?></p>
