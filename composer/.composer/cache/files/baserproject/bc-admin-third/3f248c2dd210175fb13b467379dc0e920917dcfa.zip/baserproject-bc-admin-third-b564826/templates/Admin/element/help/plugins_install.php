<?php
/**
 * baserCMS :  Based Website Development Project <https://basercms.net>
 * Copyright (c) NPO baser foundation <https://baserfoundation.org/>
 *
 * @copyright     Copyright (c) NPO baser foundation
 * @link          https://basercms.net baserCMS Project
 * @since         5.0.0
 * @license       https://basercms.net/license/index.html MIT License
 */

/**
 * プラグインのヘルプ
 */
?>


<p><?php echo __d('baser_core', 'プラグイン設定の登録を行います。<br />プラグインによってインストールメッセージが表示されている場合がありますので、内容に従います。') ?></p>

