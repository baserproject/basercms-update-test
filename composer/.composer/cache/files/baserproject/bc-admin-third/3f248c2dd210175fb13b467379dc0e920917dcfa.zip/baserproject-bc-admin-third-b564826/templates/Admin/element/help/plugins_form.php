<?php
/**
 * baserCMS :  Based Website Development Project <https://basercms.net>
 * Copyright (c) baserCMS Users Community <https://basercms.net/community/>
 *
 * @copyright       Copyright (c) baserCMS Users Community
 * @link            https://basercms.net baserCMS Project
 * @since           baserCMS v 2.0.0
 * @license         https://basercms.net/license/index.html
 */

/**
 * [ADMIN] プラグイン　ヘルプ
 */
?>


<p><?php echo __d('baser_core', 'プラグイン設定の登録を行います。<br />プラグインによってインストールメッセージが表示されている場合がありますので、内容に従います。') ?></p>
