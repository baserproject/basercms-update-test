<?php
/**
 * baserCMS :  Based Website Development Project <https://basercms.net>
 * Copyright (c) baserCMS Users Community <https://basercms.net/community/>
 *
 * @copyright       Copyright (c) baserCMS Users Community
 * @link            https://basercms.net baserCMS Project
 * @since           baserCMS v 0.1.0
 * @license         https://basercms.net/license/index.html
 */

/**
 * [ADMIN] ブログカテゴリ一覧　ヘルプ
 */
?>

<p><?php echo __d('baser_core', 'カテゴリは、記事を分類分けする際に利用します。<br>また、各カテゴリは子カテゴリを持つ事ができるようになっています。') ?></p>
