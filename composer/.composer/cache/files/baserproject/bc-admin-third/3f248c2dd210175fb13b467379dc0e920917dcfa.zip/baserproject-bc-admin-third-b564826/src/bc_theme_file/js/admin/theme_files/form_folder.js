$(function () {
    $("#BtnSave").click(function () {
        $.bcUtil.showLoader();
    });
});
