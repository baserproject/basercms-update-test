# BcAdminThird plugin for baserCMS

## About
This is the default theme for the baserCMS management system.

## Installation

You can install this plugin into your baserCMS application using [composer](https://getcomposer.org).

The recommended way to install composer packages is:

```
composer require baserproject/BcAdminThird
```

## Contributing
- [BcAdminThird の開発](https://baserproject.github.io/5/core_theme/admin_theme)
