<?php
/**
 * baserCMS :  Based Website Development Project <https://basercms.net>
 * Copyright (c) baserCMS Users Community <https://basercms.net/community/>
 *
 * @copyright       Copyright (c) baserCMS Users Community
 * @link            https://basercms.net baserCMS Project
 * @since           baserCMS v 0.1.0
 * @license         https://basercms.net/license/index.html
 */

/**
 * [ADMIN] ブログカテゴリ一覧　ヘルプ
 */
?>
<p><?php echo __d('baser_core', '記事をグルーピングする為のカテゴリ登録を行います。<br>カテゴリタイトルはTitleタグとして利用されますので、カテゴリを特定するキーワードを登録しましょう。検索エンジン対策として有用です。<br>また、各カテゴリは親カテゴリを指定する事ができ、細かく分類分けが可能です。') ?></p>
<div class="example-box">
  <div class="head"><?php echo __d('baser_core', '（例）カテゴリに属した記事のタイトルタグ出力例') ?></div>
  <p><?php echo __d('baser_core', 'カテゴリ「ニュースリリース」に属する、ブログ記事「新商品を発表しました」のタイトルタグの出力例は次のようになります。') ?></p>
  <p><?php echo __d('baser_core', '出力結果：新商品を発表しました｜ニュースリリース｜サイトタイトル') ?></p>
</div>
