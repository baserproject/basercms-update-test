<?php
/**
 * baserCMS :  Based Website Development Project <https://basercms.net>
 * Copyright (c) baserCMS Users Community <https://basercms.net/community/>
 *
 * @copyright       Copyright (c) baserCMS Users Community
 * @link            https://basercms.net baserCMS Project
 * @since           baserCMS v 0.1.0
 * @license         https://basercms.net/license/index.html
 */

/**
 * [ADMIN] スキーマ読み込みフォーム　ヘルプ
 */
?>


<p><?php echo __d('baser_core', 'スキーマファイルの読み込みテストを行えます。') ?></p>
<p>※ <?php echo __d('baser_core', '単一ファイルのみ対応') ?></p>
