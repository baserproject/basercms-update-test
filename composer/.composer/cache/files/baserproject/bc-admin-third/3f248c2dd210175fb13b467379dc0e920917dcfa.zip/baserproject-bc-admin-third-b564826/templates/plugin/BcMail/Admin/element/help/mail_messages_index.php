<?php
/**
 * baserCMS :  Based Website Development Project <https://basercms.net>
 * Copyright (c) baserCMS Users Community <https://basercms.net/community/>
 *
 * @copyright       Copyright (c) baserCMS Users Community
 * @link            https://basercms.net baserCMS Project
 * @since           baserCMS v 2.0.0
 * @license         https://basercms.net/license/index.html
 */

/**
 * [ADMIN] 受信メール一覧　ヘルプ
 */
?>


<p><?php echo __d('baser_core', '受信メールの詳細確認、削除が行えます。操作対象データのアクション欄のボタンをクリックします。') ?></p>
