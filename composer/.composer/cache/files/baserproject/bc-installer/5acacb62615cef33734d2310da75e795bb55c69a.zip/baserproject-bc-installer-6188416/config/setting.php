<?php
return [
    /**
     * システム要件
     */
    'BcRequire' => [
        'phpVersion' => "8.0.0",
        'phpMemory' => "128",
        'MySQLVersion' => "5.0.0",
        'winSQLiteVersion' => "3.7.16",
        'PostgreSQLVersion' => "8.4.0"
    ]
];
